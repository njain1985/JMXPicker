jmxmetricpicker
=======================

JMX Metric Picker

- - -
JMX Metric Picker loads all available MBeans from a specified JVM, and displays all numeric metrics for all MBeans.
It allows you to select any metrics you need to report to RPM. 


##Prerequisites

*    The JVM must be configured to have JMX enabled, and be listening on the JMX port
*    You need to use the following vm arguments, and add them to the JVM to which you are trying to connect:
*        -Dcom.sun.management.jmxremote
*        -Dcom.sun.management.jmxremote.port=<JMX_PORT_NUMBER>
*        -Dcom.sun.management.jmxremote.ssl=false
*        -Dcom.sun.management.jmxremote.authenticate=false


##Build

*    Install 'gradle' (OSX command: brew gradle)
*    clone 'jmxmetricpicker' from https://source.datanerd.us/shahram/jmxmetricpicker
*    change directory to 'jmxmetricicker' and run the following command to build the executable jar file:
*        gradle clean build
*    this will create a jar file in jmxmetricpicker/build/libs/ called jmxmetricpicker-1.0.jar



##Run

To run jmxmetricpicker from the command line type:

*    java -jar path/to/jmxmetricpicker/build/libs>/jmxmetricpicker-1.0.jar

or change directory to 'path/to/jmxmetricpicker/build/libs/' and type:

*    java -jar jmxmetricpicker-1.0.jar


The out put will be saved in the current directory where you start jmxmetricpicker, and is called 'nr_jmx.yml'. You need to copy this file to java agent's 'extensions' directory, and restart the java process, in order for it to get picked up by the agent.


