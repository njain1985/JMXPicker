package com.newrelic.jmx;

import java.awt.EventQueue;
import javax.swing.Icon;
import javax.swing.JCheckBox;

/**
 *
 * @author shahram
 */
public class TriStateCheckBox extends JCheckBox {
    private Icon currentIcon;
    
    @Override 
    public void updateUI() {
        currentIcon = getIcon();
        setIcon(null);
        super.updateUI();
        EventQueue.invokeLater(new Runnable() {
            @Override 
            public void run() {
                if (currentIcon != null) {
                    setIcon(new com.newrelic.jmx.IndeterminateIcon());
                }
                setOpaque(false);
            }
        });
    }
}
