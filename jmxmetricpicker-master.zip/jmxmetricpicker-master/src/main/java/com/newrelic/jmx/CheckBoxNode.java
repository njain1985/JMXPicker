package com.newrelic.jmx;

/**
 *
 * @author shahram
 */
public class CheckBoxNode {
    public final String label;
    public final com.newrelic.jmx.Status status;
    
    public CheckBoxNode(String label) {
        this.label = label;
        status = com.newrelic.jmx.Status.INDETERMINATE;
    }
    public CheckBoxNode(String label, com.newrelic.jmx.Status status) {
        this.label = label;
        this.status = status;
    }
    
    @Override 
    public String toString() {
        return label;
    }
}
