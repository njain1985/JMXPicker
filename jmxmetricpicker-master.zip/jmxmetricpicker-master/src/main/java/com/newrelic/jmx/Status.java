package com.newrelic.jmx;

public enum Status { 
    SELECTED, 
    DESELECTED, 
    INDETERMINATE 
}
