package com.newrelic.jmx;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTree;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeCellRenderer;
import javax.swing.tree.TreeCellRenderer;

/**
 *
 * @author shahram
 */
public class CheckBoxNodeRenderer extends com.newrelic.jmx.TriStateCheckBox implements TreeCellRenderer {
    private final DefaultTreeCellRenderer renderer = new DefaultTreeCellRenderer();
    private final JPanel panel = new JPanel(new BorderLayout());
    
    public CheckBoxNodeRenderer() {
        super();
        String uiName = getUI().getClass().getName();
        if (uiName.contains("Synth") && System.getProperty("java.version").startsWith("1.7.0")) {
            renderer.setBackgroundSelectionColor(new Color(0, 0, 0, 0));
        }
        panel.setFocusable(false);
        panel.setRequestFocusEnabled(false);
        panel.setOpaque(false);
        panel.add(this, BorderLayout.WEST);
        this.setOpaque(false);
    }
    
    @Override 
    public Component getTreeCellRendererComponent(JTree tree, Object value, boolean selected, boolean expanded, boolean leaf, int row, boolean hasFocus) {
        JLabel l = (JLabel) renderer.getTreeCellRendererComponent(tree, value, selected, expanded, leaf, row, hasFocus);
        l.setFont(tree.getFont());
        if (value instanceof DefaultMutableTreeNode) {
            this.setEnabled(tree.isEnabled());
            this.setFont(tree.getFont());
            Object userObject = ((DefaultMutableTreeNode) value).getUserObject();
            if (userObject instanceof com.newrelic.jmx.CheckBoxNode) {
                com.newrelic.jmx.CheckBoxNode node = (com.newrelic.jmx.CheckBoxNode) userObject;
                if (node.status == com.newrelic.jmx.Status.INDETERMINATE) {
                    setIcon(new com.newrelic.jmx.IndeterminateIcon());
                } else {
                    setIcon(null);
                }
                l.setText(node.label);
                setSelected(node.status == com.newrelic.jmx.Status.SELECTED);
            }
            //panel.add(this, BorderLayout.WEST);
            panel.add(l);
            return panel;
        }
        return l;
    }
    
    @Override 
    public void updateUI() {
        super.updateUI();
        if (panel != null) {
            panel.updateUI();
        }
        setName("Tree.cellRenderer");
    }
}

