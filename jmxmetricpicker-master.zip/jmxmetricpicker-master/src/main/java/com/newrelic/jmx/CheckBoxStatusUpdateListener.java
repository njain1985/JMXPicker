package com.newrelic.jmx;

import java.util.Enumeration;
import java.util.Objects;
import javax.swing.event.TreeModelEvent;
import javax.swing.event.TreeModelListener;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.TreePath;

/**
 *
 * @author shahram
 */
public class CheckBoxStatusUpdateListener implements TreeModelListener {
    private boolean adjusting;
    
    @Override 
    public void treeNodesChanged(TreeModelEvent e) {
        if (adjusting) {
            return;
        }
        adjusting = true;
        TreePath parent = e.getTreePath();
        Object[] children = e.getChildren();
        DefaultTreeModel model = (DefaultTreeModel) e.getSource();

        DefaultMutableTreeNode node;
        com.newrelic.jmx.CheckBoxNode c; // = (CheckBoxNode) node.getUserObject();
        if (children != null && children.length == 1) {
            node = (DefaultMutableTreeNode) children[0];
            c = (com.newrelic.jmx.CheckBoxNode) node.getUserObject();
            DefaultMutableTreeNode n = (DefaultMutableTreeNode) parent.getLastPathComponent();
            while (n != null) {
                updateParentUserObject(n);
                DefaultMutableTreeNode tmp = (DefaultMutableTreeNode) n.getParent();
                if (tmp == null) {
                    break;
                } else {
                    n = tmp;
                }
            }
            model.nodeChanged(n);
        } else {
            node = (DefaultMutableTreeNode) model.getRoot();
            c = (com.newrelic.jmx.CheckBoxNode) node.getUserObject();
        }
        updateAllChildrenUserObject(node, c.status);
        model.nodeChanged(node);
        adjusting = false;
    }
    
    private void updateParentUserObject(DefaultMutableTreeNode parent) {
        String label = ((com.newrelic.jmx.CheckBoxNode) parent.getUserObject()).label;
        int selectedCount = 0;
        int indeterminateCount = 0;
        Enumeration children = parent.children();
        while (children.hasMoreElements()) {
            DefaultMutableTreeNode node = (DefaultMutableTreeNode) children.nextElement();
            com.newrelic.jmx.CheckBoxNode check = (com.newrelic.jmx.CheckBoxNode) node.getUserObject();
            if (check.status == com.newrelic.jmx.Status.INDETERMINATE) {
                indeterminateCount++;
                break;
            }
            if (check.status == com.newrelic.jmx.Status.SELECTED) {
                selectedCount++;
            }
        }
        if (indeterminateCount > 0) {
            parent.setUserObject(new com.newrelic.jmx.CheckBoxNode(label));
        } else if (selectedCount == 0) {
            parent.setUserObject(new com.newrelic.jmx.CheckBoxNode(label, com.newrelic.jmx.Status.DESELECTED));
        } else if (selectedCount == parent.getChildCount()) {
            parent.setUserObject(new com.newrelic.jmx.CheckBoxNode(label, com.newrelic.jmx.Status.SELECTED));
        } else {
            parent.setUserObject(new com.newrelic.jmx.CheckBoxNode(label));
        }
    }
    
    private void updateAllChildrenUserObject(DefaultMutableTreeNode root, com.newrelic.jmx.Status status) {
        Enumeration breadth = root.breadthFirstEnumeration();
        while (breadth.hasMoreElements()) {
            DefaultMutableTreeNode node = (DefaultMutableTreeNode) breadth.nextElement();
            if (Objects.equals(root, node)) {
                continue;
            }
            com.newrelic.jmx.CheckBoxNode check = (com.newrelic.jmx.CheckBoxNode) node.getUserObject();
            node.setUserObject(new com.newrelic.jmx.CheckBoxNode(check.label, status));
        }
    }
    
    @Override 
    public void treeNodesInserted(TreeModelEvent e) {
        
    }
    
    @Override 
    public void treeNodesRemoved(TreeModelEvent e) {
        
    }
    
    @Override 
    public void treeStructureChanged(TreeModelEvent e) {
        
    }
}
