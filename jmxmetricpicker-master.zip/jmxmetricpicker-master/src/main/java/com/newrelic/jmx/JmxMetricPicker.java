package com.newrelic.jmx;

import java.awt.Dimension;
import java.awt.Toolkit;
import java.awt.event.KeyEvent;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.management.ManagementFactory;
import java.net.MalformedURLException;
import java.util.Enumeration;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.management.InstanceNotFoundException;
import javax.management.IntrospectionException;
import javax.management.MBeanAttributeInfo;
import javax.management.MBeanServer;
import javax.management.MBeanServerConnection;
import javax.management.MBeanServerFactory;
import javax.management.MalformedObjectNameException;
import javax.management.ObjectName;
import javax.management.ReflectionException;
import javax.management.remote.JMXConnector;
import javax.management.remote.JMXConnectorFactory;
import javax.management.remote.JMXServiceURL;
import javax.swing.BorderFactory;
import javax.swing.JTree;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.TreeModel;
//import javax.swing.JScrollPane;
//import javax.swing.tree.TreePath;


//enum Status { SELECTED, DESELECTED, INDETERMINATE }


public class JmxMetricPicker extends javax.swing.JFrame {

    DefaultMutableTreeNode root = null;
    JTree tree = null;
    DefaultTreeModel model = null;


    public JmxMetricPicker() {
        initComponents();
        setPreferredSize(new Dimension(640, 480));
        
        Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
        setLocation((int)((dim.width-getSize().width)/2), (int)((dim.height-getSize().height)/2));
    }

    private static DefaultMutableTreeNode buildJmxTree(MBeanServerConnection jmxConnection) throws IOException, MalformedObjectNameException { 

        DefaultMutableTreeNode rootNode = new DefaultMutableTreeNode("Jmx Servers Domains");
        for (String domain : jmxConnection.getDomains()) {
            DefaultMutableTreeNode currentDomainNode = new DefaultMutableTreeNode(domain);
            //rootNode.add(currentDomainNode);

            Set<ObjectName> mb = jmxConnection.queryNames(new ObjectName(domain + ":*"), null);
            TreeSet<ObjectName> mbeans = new TreeSet<ObjectName>();
            mbeans.addAll(mb);
            
            //SortedSet<ObjectName> mbean = jmxConnection.queryNames(new ObjectName(domain + ":*"), null);

            int mbeanCount = 0;
            for (final ObjectName mbean : mbeans) {
                try {
                    // add mbean name as a treenode under the server tgree node
                    // mbean
                    DefaultMutableTreeNode currentMBeanNode = new DefaultMutableTreeNode(mbean.getCanonicalName());
                    //DefaultMutableTreeNode currentMBeanNode = new DefaultMutableTreeNode(mbean.getKeyProperty("name"));

                    final MBeanAttributeInfo[] attributes = jmxConnection.getMBeanInfo(mbean).getAttributes();
                    int attributeCount = 0;
                    for (final MBeanAttributeInfo attribute : attributes) {
                        // for each mbean spit out attribute names
                        // attribute.getName()
                        try {
                            if (attribute.getType().equals("int") || attribute.getType().equals("long")) {
                                DefaultMutableTreeNode attributeNode = new DefaultMutableTreeNode(attribute.getName());
                                currentMBeanNode.add(attributeNode);
                                attributeCount |= 1;
                                mbeanCount |= 1;
                            }
                        } catch (NullPointerException e) {}
                    }
                    if (attributeCount > 0) {
                        currentDomainNode.add(currentMBeanNode);
                    }
                    else {
                        currentMBeanNode = null;
                    }
                } catch (InstanceNotFoundException ex) {
                    Logger.getLogger(JmxMetricPicker.class.getName()).log(Level.SEVERE, null, ex);
                } catch (IntrospectionException ex) {
                    Logger.getLogger(JmxMetricPicker.class.getName()).log(Level.SEVERE, null, ex);
                } catch (ReflectionException ex) {
                    Logger.getLogger(JmxMetricPicker.class.getName()).log(Level.SEVERE, null, ex);
                } catch (IOException ex) {
                    Logger.getLogger(JmxMetricPicker.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
            if (mbeanCount > 0) {
                rootNode.add(currentDomainNode);
            }
            else {
                currentDomainNode = null;
            }
        } // per domain
   		return rootNode;
	}

        
    private static DefaultMutableTreeNode buildJmxTree() throws Throwable { 

        DefaultMutableTreeNode rootNode = new DefaultMutableTreeNode("Jmx Servers");
        
        final java.util.List<MBeanServer> servers = new LinkedList<>();
        servers.add(ManagementFactory.getPlatformMBeanServer());
        //servers.addAll(MBeanServerFactory.findMBeanServer(null));
    
        for (final MBeanServer server : servers) {
            // add server name as a node + 
            // server.getClass().getName();
            DefaultMutableTreeNode currentServerNode = new DefaultMutableTreeNode(server.getClass().getName());
            rootNode.add(currentServerNode);

            final Set<ObjectName> mbeans = new HashSet<>();
            mbeans.addAll(server.queryNames(new ObjectName("*:*"), null));
            //mbeans.addAll(server.queryNames(null, null));

            for (final ObjectName mbean : mbeans) {
                // add mbean name as a treenode under the server tgree node
                // mbean
                DefaultMutableTreeNode currentMBeanNode = new DefaultMutableTreeNode(mbean.getCanonicalName());
                //DefaultMutableTreeNode currentMBeanNode = new DefaultMutableTreeNode(mbean.getKeyProperty("name"));
                
                final MBeanAttributeInfo[] attributes = server.getMBeanInfo(mbean).getAttributes();
                int attributeCount = 0;
                for (final MBeanAttributeInfo attribute : attributes) {
                    // for each mbean spit out attribute names
                    // attribute.getName()
                    if (attribute.getType().equals("int") || attribute.getType().equals("long")) {
                        DefaultMutableTreeNode attributeNode = new DefaultMutableTreeNode(attribute.getName());
                        currentMBeanNode.add(attributeNode);
                        attributeCount++;
                    }
                }
                if (attributeCount > 0) {
                    currentServerNode.add(currentMBeanNode);
                }
                else {
                    currentMBeanNode = null;
                }
            }
        }

   		return rootNode;
	}
    
    private void addTree() {
        
        tree = new JTree(root) {
            @Override public void updateUI() {
                setCellRenderer(null);
                setCellEditor(null);
                super.updateUI();
                //???#1: JDK 1.6.0 bug??? Nimbus LnF
                setCellRenderer(new CheckBoxNodeRenderer());
                setCellEditor(new CheckBoxNodeEditor());
            }
        };
        jScrollPane1.setViewportView(tree);
        
        TreeModel treeModelodel = tree.getModel();
        DefaultMutableTreeNode rootNode = (DefaultMutableTreeNode) treeModelodel.getRoot();
        Enumeration e = rootNode.breadthFirstEnumeration();
        while (e.hasMoreElements()) {
            DefaultMutableTreeNode node = (DefaultMutableTreeNode) e.nextElement();
            Object obj = node.getUserObject();
            if (obj instanceof String) {
                node.setUserObject(new CheckBoxNode((String) obj, Status.DESELECTED));
            }
        }
        treeModelodel.addTreeModelListener(new CheckBoxStatusUpdateListener());
        tree.setEditable(true);
        tree.setBorder(BorderFactory.createEmptyBorder(4, 4, 4, 4));

        tree.expandRow(0);
        //tree.setToggleClickCount(1);

        
    }
    
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        serverName = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        serverPort = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        exitButton = new javax.swing.JButton();
        buildButton = new javax.swing.JButton();
        loadButton = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        msgBox = new javax.swing.JTextArea();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setText("server:");

        serverName.setText("localhost");
        serverName.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                serverNameActionPerformed(evt);
            }
        });
        serverName.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                ServerNameKeyPressed(evt);
            }
        });

        jLabel2.setText("port:");

        serverPort.setText("8080");
        serverPort.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                ServerPortKeyPressed(evt);
            }
        });

        exitButton.setText("exit");
        exitButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                exitButtonActionPerformed(evt);
            }
        });

        buildButton.setText("build yml");
        buildButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buildButtonActionPerformed(evt);
            }
        });

        loadButton.setText("Load MBeans");
        loadButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                loadButtonActionPerformed(evt);
            }
        });

        msgBox.setColumns(20);
        msgBox.setRows(5);
        msgBox.setBorder(javax.swing.BorderFactory.createTitledBorder("Status"));
        msgBox.setRequestFocusEnabled(false);
        jScrollPane2.setViewportView(msgBox);

        org.jdesktop.layout.GroupLayout layout = new org.jdesktop.layout.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(layout.createSequentialGroup()
                .addContainerGap()
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(layout.createSequentialGroup()
                        .add(jScrollPane2, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 423, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .add(buildButton)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(exitButton, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 90, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap())
                    .add(jScrollPane1)
                    .add(layout.createSequentialGroup()
                        .add(jLabel1)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(serverName, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 339, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.UNRELATED)
                        .add(jLabel2, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 30, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(serverPort, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .add(18, 18, 18)
                        .add(loadButton)
                        .add(0, 0, Short.MAX_VALUE))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(layout.createSequentialGroup()
                .add(8, 8, 8)
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(jLabel1)
                    .add(serverName, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(jLabel2)
                    .add(serverPort, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(loadButton))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jScrollPane1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 333, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(layout.createSequentialGroup()
                        .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                            .add(exitButton)
                            .add(buildButton))
                        .add(0, 0, Short.MAX_VALUE))
                    .add(jScrollPane2, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 111, Short.MAX_VALUE))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void exitButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_exitButtonActionPerformed
        //this.removeAll();
        System.exit(0);
    }//GEN-LAST:event_exitButtonActionPerformed

    private void loadButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_loadButtonActionPerformed
        try {
            if (serverName.getText().isEmpty() || serverPort.getText().isEmpty()) {
                msgBox.setText("Please enter valid JMX server and port...");                
            }
            else {
                MBeanServerConnection jmxConn;
                String hostname = serverName.getText();
                Integer port = Integer.valueOf(serverPort.getText());
                //Hashtable h = new Hashtable();
                JMXServiceURL address = new JMXServiceURL("service:jmx:rmi:///jndi/rmi://"+hostname+":"+port+"/jmxrmi");
                JMXConnector connector = JMXConnectorFactory.connect(address,null);
                jmxConn = connector.getMBeanServerConnection();
                msgBox.setText("successfully connected to MBeanServer...");
                root = buildJmxTree(jmxConn);
                addTree();
            } 
        } catch (MalformedURLException ex) {
            Logger.getLogger(JmxMetricPicker.class.getName()).log(Level.SEVERE, null, ex);
            msgBox.setText("Exception: MalformedURLException while connecting to jmx server...");
        } catch (IOException ex) {
            Logger.getLogger(JmxMetricPicker.class.getName()).log(Level.SEVERE, null, ex);
            msgBox.setText("Exception: IOException while connecting to jmx server...");
        } catch (Throwable ex) {
            Logger.getLogger(JmxMetricPicker.class.getName()).log(Level.SEVERE, null, ex);
            msgBox.setText("Error - please check the log...");
        }

    }//GEN-LAST:event_loadButtonActionPerformed

    private void buildButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buildButtonActionPerformed
        
        msgBox.setText(null);
        //msgBox.removeAll();

        if(((CheckBoxNode)root.getUserObject()).status == Status.DESELECTED) { // no leaf in the tree has been selected
            msgBox.setText("No metrics selected...");
        }
        else {
            String outFileName = "nr_jmx.yml";
            try (FileWriter fw = new FileWriter(outFileName)) {
                fw.write("name: Custom JMX\n" + 
                        "version: 1.0\n" +
                        "enabled: true\n\n" +
                        "jmx:\n");

                String currentParentName = null;
                String previousParentName = null;
                String jmxMetrics = "";
                int metricCounter = 0;
                Enumeration e = root.breadthFirstEnumeration();
                while (e.hasMoreElements()) {
                    DefaultMutableTreeNode node = (DefaultMutableTreeNode) e.nextElement();

                    if(node.isLeaf() && ((CheckBoxNode)node.getUserObject()).status == Status.SELECTED) {
                        currentParentName = node.getParent().toString();
                        if (!currentParentName.equals(previousParentName)) {
                            if (metricCounter > 0) {
                                fw.write("  - object_name: " + previousParentName + "\n");
                                jmxMetrics = jmxMetrics.substring(0,jmxMetrics.length()-2);
                                fw.write("    metrics:\n      - attributes: " + jmxMetrics + "\n\n");
                                metricCounter = 0;
                                jmxMetrics = "";
                            }
                            previousParentName = currentParentName;
                        }

                        jmxMetrics = jmxMetrics + node.toString() + ", ";
                        metricCounter++;

                        msgBox.append(node.getParent().toString() + " | " + node.toString() + "\n");
                    }

                }
                if (metricCounter > 0) {
                    fw.write("  - object_name: " + previousParentName + "\n");
                    jmxMetrics = jmxMetrics.substring(0,jmxMetrics.length()-2);
                    fw.write("    metrics:\n      - attributes: " + jmxMetrics + "\n\n");
                }

                fw.flush();
                fw.close();
            } catch (IOException ex) {
                Logger.getLogger(JmxMetricPicker.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        
    }//GEN-LAST:event_buildButtonActionPerformed

    private void serverNameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_serverNameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_serverNameActionPerformed

    private void ServerNameKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_ServerNameKeyPressed
        int key = evt.getKeyCode();
        
        if (key == KeyEvent.VK_ENTER) {
            loadButton.requestFocus();
            loadButton.doClick();
        }

    }//GEN-LAST:event_ServerNameKeyPressed

    private void ServerPortKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_ServerPortKeyPressed
        int key = evt.getKeyCode();
        
        if (key == KeyEvent.VK_ENTER) {
            loadButton.requestFocus();
            loadButton.doClick();
        }

    }//GEN-LAST:event_ServerPortKeyPressed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(JmxMetricPicker.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                new JmxMetricPicker().setVisible(true);
            }
        });
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton buildButton;
    private javax.swing.JButton exitButton;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JButton loadButton;
    private javax.swing.JTextArea msgBox;
    private javax.swing.JTextField serverName;
    private javax.swing.JTextField serverPort;
    // End of variables declaration//GEN-END:variables
}
